﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Windows.Threading;
using System.Timers;
using System.Net.Http;

namespace FieldControl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SerialPort port;

        TimeSpan _time;
        System.Timers.Timer timer;

        int redCount = 0;
        int blueCount = 0;

        public int MATCH_TIME = 20;
        public int AUTO_TIME = 10;
        public int matchMode = 1;
        public int redAutoCount, blueAutoCount = 0;

        private static readonly HttpClient client = new HttpClient();


        public MainWindow()
        {
            InitializeComponent();
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += TICK;

            
        }

        private void StartMatchButton_Click(object sender, RoutedEventArgs e)
        {
            /*if (!port.IsOpen)
            {
                outputLabel.Content = "port not open";
                return;
            }*/
            MATCH_TIME = Convert.ToInt16(TotalTime.Text);
            AUTO_TIME = Convert.ToInt16(AutoTime.Text);

            if (matchMode == 2)
            {
                port.Write("ET");
                
                timer.Start();
            } else
            {
                port.Write("EA");
                port.Write("MM");
                _time = TimeSpan.FromSeconds(MATCH_TIME);
                this.MatchTimeLabel.Content = _time.ToString(@"mm\:ss").Remove(0, 1);
                timer.Start();
            }
            


            

        }

        public void TICK(object sender, EventArgs e)
        {
            _time = _time.Add(TimeSpan.FromSeconds(-1));
            Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Normal, 
                new Action(() => this.MatchTimeLabel.Content = _time.ToString(@"mm\:ss").Remove(0,1)));
            if (_time == TimeSpan.Zero)
            {
                port.Write("DI");
                timer.Stop();
                matchMode = 1;
            }
            else if (_time.TotalSeconds == (MATCH_TIME - AUTO_TIME))
            {
                matchMode = 2;
                port.Write("DI");
                timer.Stop();
            }
            PostTime();
            GetCount();
        }

        public void SetTime(string time)
        {
            MatchTimeLabel.Content = time;
            
        }

        void GetCount()
        {
            port.Write("CN");
            string ret = port.ReadLine();
            string[] split = ret.Split(' ');
            redCount = Convert.ToInt16(split[0]);
            blueCount = Convert.ToInt16(split[1]);
            PostBallCount(redCount, blueCount, (_time.TotalSeconds >= (MATCH_TIME - AUTO_TIME)));
            Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Normal,
               new Action(() => this.outputLabel.Content = ret));
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            port = new SerialPort(PortBox.Text, 9600,
                Parity.None, 8, StopBits.One);
            try
            {
                port.Open();
                outputLabel.Content = "port open";
            }
            catch (Exception E)
            {
                outputLabel.Content = E.ToString();
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            port.Write("RE");
            timer.Stop();
            matchMode = 1;
            redAutoCount = 0;
            blueAutoCount = 0;
        }

        public void PostTime()
        {
            var values = new Dictionary<string, string>
            {
               { "match_time", _time.TotalSeconds.ToString() }
            };

            var content = new FormUrlEncodedContent(values);

            client.PostAsync("http://localhost/JRL2018/php/updateStatus.php", content);
        }

        public void PostBallCount(int _redCount, int _blueCount, bool auto)
        {
            var values = new Dictionary<string, string>();
            if (auto)
            {
                values.Add( "red_auto_cannon",_redCount.ToString());
                values.Add("blue_auto_cannon",_blueCount.ToString());
                redAutoCount = _redCount;
                blueAutoCount = _blueCount;
            } else
            {
                values.Add("red_cannon", (_redCount - redAutoCount).ToString());
                values.Add("blue_cannon", (_blueCount - blueAutoCount).ToString());
            }
            

            var content = new FormUrlEncodedContent(values);

            client.PostAsync("http://localhost/JRL2018/php/sendScore.php", content);
        }
    }
}
